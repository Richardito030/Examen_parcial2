import requests
base_url = 'http://localhost:5000'
#---------------------------------------------------------------------------------------------------


def registrar_profesor(id, nombre, correo, direccion):
    url = f'{base_url}/profesores/registrar'
    profesor = {
        "id": id,
        "nombre": nombre,
        "correo": correo,
        "direccion": direccion
    }
    try:
        response = requests.post(url, json=profesor)
        if response.status_code == 200:
            return True, response.json()
        else:
            return False, f"Error: {response.status_code}, {response.text}"
    except requests.exceptions.RequestException as e:
        return False, f"Error en la conexión: {str(e)}"
    


#---------------------------------------------------------------------------------------------------


def consultar_profesor_id():
    identificador = int(input("id: "))
    url = f'{base_url}/profesores/consultar_i/{identificador}'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        print(data)
    else:
        print(f'Error al consultar : {response.status_code}')


#---------------------------------------------------------------------------------------------------


def consultar_profesor_nombre():
    nombre = input("Nombre: ") 
    url = f'{base_url}/profesores/consultar_n/{nombre}'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        print(data)
    else:
        print(f'Error al consultar : {response.status_code}')


#---------------------------------------------------------------------------------------------------


def consultar_profesor_correo():
    correo = input("Correo: ") 
    url = f'{base_url}/profesores/consultar_c/{correo}'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        print(data)
    else:
        print(f'Error al consultar : {response.status_code}')


#--------------------------------------------------------------------------------------------------


def consultar_profesor_direccion():
    direccion = input("Nombre: ") 
    url = f'{base_url}/profesores/consultar_d/{direccion}'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        print(data)
    else:
        print(f'Error al consultar: {response.status_code}')


#---------------------------------------------------------------------------------------------------------


def agregar():
    identificador = int(input("id: "))
    nombre = input("Nombre: ")
    correo = input("Email: ")
    direccion = input("Dirección: ")

    success, result = registrar_profesor(identificador, nombre, correo, direccion)
    if success:
        print("Profesor guardado.")
        print(result)
    else:
        print("Error al registrar:")
        print(result)


#--------------------------------------------------------------------------------------------


def consultar():
    con = True
    while con:
        print("Opciones de consulta?\n1. Id\n2. Nombre\n3. Correo\n4. Direccion\n5. Salir")
        opcion = int(input("Escribe una opcion: "))
        if opcion == 1:
            consultar_profesor_id()
        elif opcion == 2:
            consultar_profesor_nombre()
        elif opcion == 3:
            consultar_profesor_correo()
        elif opcion == 4:
            consultar_profesor_direccion()
        elif opcion == 5:
            print("Ha salido de la API")
            con = False
        else:
            print("Opcion no valida, intente nuevamente")


#----------------------------------------------------------------------------------------------------


def modificar_usuario_n():
    identificador = int(input("Ingresa el id del usuario a modificar: "))

    url = f'{base_url}/profesores/modificar_n/{identificador}'

    nombre = input("Introduce el nombre: ")

    data = {
        'nombre': nombre
    }

    response = requests.put(url, json=data)

    if response.status_code == 200:
        result = response.json()
        print(result)
    else:
        print(f'Error al actualizar : {response.status_code}')


#---------------------------------------------------------------------------------------------------


def modificar_usuario_c():
    identificador = int(input("Introduce el id del usuario a modificar: "))

    url = f'{base_url}/profesores/modificar_c/{identificador}'

    correo = input("Introduce el correo nuevo: ")

    data = {
        'correo': correo
    }

    response = requests.put(url, json=data)

    if response.status_code == 200:
        result = response.json()
        print(result)
    else:
        print(f'Error al actualizar el correo: {response.status_code}')


#---------------------------------------------------------------------------------------------------


def modificar_usuario_t():
    identificador = int(input("Digita el id: "))
    url = f'{base_url}/profesores/modificar/{identificador}'

    nombre = input("Nombre: ")
    correo = input("Email: ")
    direccion = input("Dirección: ")

    data = {
        'nombre': nombre,
        'correo': correo,
        'direccion': direccion
    }

    response = requests.put(url, json=data)
    if response.status_code == 200:
        result = response.json()
        print(result)
    else:
        print(f'Error al actualizar el usuario: {response.status_code}')


#---------------------------------------------------------------------------------------------------


def modificar():
    con = True
    while con:
        print("Que deseas modificar?\n1. Nombre\n2. Correo\n3. Todo\n4. Salir")
        opcion = int(input("Digita una opcion: "))
        if opcion == 1:
            modificar_usuario_n()
        elif opcion == 2:
            modificar_usuario_c()
        elif opcion == 3:
            modificar_usuario_t()
        elif opcion == 4:
            con = False
        else:
            print("Ingresa una opcion valida")


#---------------------------------------------------------------------------------------------------


def eliminar_usuario_id():
    identificador = int(input("Digita el id del usuario a eliminar: "))

    url = f'{base_url}/profesores/eliminar_id/{identificador}'

    response = requests.delete(url)

    if response.status_code == 200:
        result = response.json()
        print(result)
    else:
        print(f'Error al eliminar el usuario: {response.status_code}')


#---------------------------------------------------------------------------------------------------


def eliminar_usuario_nombre():
    nombre = input("Digita el nombre del usuario a eliminar: ")

    url = f'{base_url}/profesores/eliminar_nombre/{nombre}'

    response = requests.delete(url)

    if response.status_code == 200:
        result = response.json()
        print(result)
    else:
        print(f'Error al eliminar el usuario: {response.status_code}')


#---------------------------------------------------------------------------------------------------


def eliminar_usuario_por_correo():
    correo = input("Digita el correo del usuario a eliminar: ")

    url = f'{base_url}/profesores/eliminar_correo/{correo}'

    response = requests.delete(url)

    if response.status_code == 200:
        result = response.json()
        print(result)
    else:
        print(f'Error al eliminar el usuario: {response.status_code}')


#---------------------------------------------------------------------------------------------------


def eliminar():
    con = True
    while con:
        print("Escoge un identificador \n1. Id\n2. Nombre\n3. Correo\n4. Salir")
        opcion = int(input("Digita una opcion: "))
        if opcion == 1:
            eliminar_usuario_id()
        if opcion == 2:
            eliminar_usuario_nombre()
        if opcion == 3:
            eliminar_usuario_por_correo()
        if opcion == 4:
            con = False
        else:
            print("Ingresa una opcion valida")


#---------------------------------------------------------------------------------------------------


def reportar():
    url = f'{base_url}/profesores'

    response = requests.get(url)

    if response.status_code == 200:
        profesores = response.json()
        for profesor in profesores:
            print(profesor)
    else:
        print(f'Error al obtener los profesores: {response.status_code}')


#---------------------------------------------------------------------------------------------------
opc = True
while opc:
    print("\t Escoja una opcion valida \n1Agregar \n2 Consultar\n3 Modificar\n4 Eliminar \n5 Reportar\n6 Salir")
    opc = int(input("Digita una opcion: "))
    if opc == 1:
        agregar()
    elif opc == 2:
        consultar()
    elif opc == 3:
        modificar()
    elif opc == 4:
        eliminar()
    elif opc == 5:
        reportar()
    elif opc == 6:
        print("Saliendo...")
        opc = False
    else:
        print("Opcion novalida")
