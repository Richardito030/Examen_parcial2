const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(bodyParser.json());
app.use(cors());


const db = mysql.createPool({
    host: '189.197.187.187',
    user: 'alumnos',
    password: 'Alumnos1010$',
    database: 'controlescolar',
});

app.get('/', (req, res) => {
    res.send("Hola mundo 2");
});

app.get('/profesores', (req, res) => {
    const sql = 'SELECT * FROM profesores';
    db.query(sql, (err, result) => {
        if (!err) {
            res.status(200).send(result);
        } else {
            res.status(300).send(err);
        }
    });
});

app.get('/profesores/consultar_i/:id', (req, res) => {
    const identificador = req.params.id;
    const sql = 'SELECT * FROM profesores WHERE id = ?';
    db.query(sql, [identificador], (err, result) => {
        if (!err) {
            res.status(200).send(result);
        } else {
            res.status(300).send(err);
        }
    });
});

app.get('/profesores/consultar_n/:nombre', (req, res) => {
    const nombres = req.params.nombre;
    const sql = 'SELECT * FROM profesores WHERE nombre = ?';
    db.query(sql, [nombres], (err, result) => {
        if (!err) {
            res.status(200).send(result);
        } else {
            res.status(300).send(err);
        }
    })
})

app.get('/profesores/consultar_c/:correo', (req, res) => {
    const correos = req.params.correo;
    const sql = 'SELECT * FROM profesores WHERE correo = ?';
    db.query(sql, [correos], (err, result) => {
        if (!err) {
            res.status(200).send(result);
        } else {
            res.status(300).send(err);
        }
    })
})

app.get('/profesores/consultar_d/:direccion', (req, res) => {
    const direcciones = req.params.nombre;
    const sql = 'SELECT * FROM profesores WHERE direccion = ?';
    db.query(sql, [direcciones], (err, result) => {
        if (!err) {
            res.status(200).send(result);
        } else {
            res.status(300).send(err);
        }
    })
})

app.get('/profesores', (req, res) => {
    const respuesta = {
        "id": 5,
        "nombre": "Dagoberto Fiscal",
        "correo": "dago@gmail.com",
        "direccion": "5 de febrero",
        "telefono": "6181233848"
    };
    res.status(200).send(respuesta);
});

app.post('/profesores/registrar', (req, res) => {
    const { id, nombre, correo, direccion } = req.body;
    const sql = 'INSERT INTO profesores (id, nombre, correo, direccion) VALUES (?, ?, ?, ?)';
    db.query(sql, [id, nombre, correo, direccion], (err, resultado) => {
        if (!err) {
            res.status(200).send({
                resultado,
                mensaje: 'Profesor registrado',
            });
        } else {
            res.status(300).send({
                err,
                mensaje: 'No se registró el profesor',
            });
        }
    });
});

app.put('/profesores/modificar/:id', (req, res) => {
    const id = req.params.id;  
    const { nombre, correo, direccion } = req.body;
    const sql = 'UPDATE profesores SET nombre = ?, correo = ?, direccion = ? WHERE id = ?';
    db.query(sql, [nombre, correo, direccion, id], (err, result) => {
        if (!err) {
            res.status(200).send({
                result,
                mensaje: 'Profesor modificado',
            });
        } else {
            res.status(500).send({  
                err,
                mensaje: 'No se modificó el profesor',
            });
        }
    });
});

app.put('/profesores/modificar_n/:id', (req, res) => {
    const id = req.params.id;
    const { nombre } = req.body;
    const sql = 'UPDATE profesores SET nombre = ? WHERE id = ?';
    db.query(sql, [nombre, id], (err, result) => {
        if (!err) {
            res.status(200).json({ message: 'Nombre del usuario actualizado con éxito' });
        } else {
            res.status(500).json(err); 
        }
    });
});

app.put('/profesores/modificar_c/:id', (req, res) => {
    const id = req.params.id;
    const { correo } = req.body;
    const sql = 'UPDATE profesores SET correo = ? WHERE id = ?';
    db.query(sql, [correo, id], (err, result) => {
        if (!err) {
            res.status(200).json({ message: 'Nombre del usuario actualizado con éxito' });
        } else {
            res.status(500).json(err); 
        }
    });
});

app.delete('/profesores/eliminar_id/:id', (req, res) => {
    const identificador = req.params.id;
    const sql = 'DELETE FROM profesores WHERE id = ?';
    db.query(sql, [identificador], (err, result) => {
        if (!err) {
            res.status(200).send(result);
        } else {
            res.status(300).send(err);
        }
    });
});

app.delete('/profesores/eliminar_nombre/:nombre', (req, res) => {
    const nombre = req.params.nombre;
    const sql = 'DELETE FROM profesores WHERE nombre = ?';
    db.query(sql, [nombre], (err, result) => {
        if (!err) {
            res.status(200).json({ message: 'Profesor eliminado con éxito' });
        } else {
            res.status(500).json(err); 
        }
    });
});

app.delete('/profesores/eliminar_correo/:correo', (req, res) => {
    const correo = req.params.correo;
    const sql = 'DELETE FROM profesores WHERE correo = ?';
    db.query(sql, [correo], (err, result) => {
        if (!err) {
            res.status(200).json({ message: 'Profesor eliminado con éxito' });
        } else {
            res.status(500).json(err); 
        }
    });
});

app.all('*', (req, res) => {
    res.send("Esta dirección no existe, contacta a tu administrador o proveedor");
});

app.listen(port, () => {
    console.log(`Escuchando en el puerto ${port}`);
});
